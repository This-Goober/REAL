REAL HIMAS 2027 anonymous review draft. Main file: main.tex.
Compile main.tex with XeLaTeX, then BibTeX main, then XeLaTeX twice.
This package is not a submission. Authors must approve the content,
metadata, and AI declaration and verify final archival requirements.
